// DEPRECATED: This helper is no longer used for upload/download logic.
// All upload/download logic is now handled in working.js only. 